#region Copyright (c) IFS Research & Development
// ======================================================================================================
//
//                 IFS Research & Development
//
//  This program is protected by copyright law and by international
//  conventions. All licensing, renting, lending or copying (including
//  for private use), and all other use of the program, which is not
//  explicitly permitted by IFS, is a violation of the rights
//  of IFS. Such violations will be reported to the
//  appropriate authorities.
//
//  VIOLATIONS OF ANY COPYRIGHT IS PUNISHABLE BY LAW AND CAN LEAD
//  TO UP TO TWO YEARS OF IMPRISONMENT AND LIABILITY TO PAY DAMAGES.
// ======================================================================================================
#endregion
#region History
#endregion

using System;
using System.Text;
using System.Drawing;
using System.Diagnostics;
using System.Collections;
using System.Windows.Forms;
using System.ComponentModel;
using Ifs.Fnd.ApplicationForms;
using PPJ.Runtime;
using PPJ.Runtime.Sql;
using PPJ.Runtime.Vis;
using PPJ.Runtime.Windows;
using PPJ.Runtime.Windows.QO;

namespace Ifs.Application.Trninv
{
	
	/// <summary>
	/// </summary>
	[FndWindowRegistration("TRN_INVENTORY_PRODUCT", "TrnInventoryProduct")]
	public partial class tbwInventoryProductOverview : cTableWindow
	{

        #region Window Variables
        #endregion

		#region Constructors/Destructors
		
		/// <summary>
		/// Default Constructor.
		/// </summary>
		public tbwInventoryProductOverview()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();
		}
		#endregion
		
		#region System Methods/Properties
		
		
		/// <summary>
		/// Returns the object instance associated with the window handle.
		/// </summary>
		/// <param name="handle"></param>
		/// <returns></returns>
		public new static tbwInventoryProductOverview FromHandle(SalWindowHandle handle)
		{
			return ((tbwInventoryProductOverview)SalWindow.FromHandle(handle, typeof(tbwInventoryProductOverview)));
		}
		#endregion
		
		#region Methods
	
		/// <summary>
		/// </summary>
		/// <returns></returns>
		public virtual SalNumber SetWindowTitle()
		{
			#region Local Variables
			SalArray<SalString> sItems = new SalArray<SalString>();
			#endregion
			
			#region Actions
			using (new SalContext(this))
			{
				UserGlobalValueGet("COMPANY_ID", ref sItems.GetArray(0)[0]);
				Sal.SetWindowText(i_hWndFrame, Ifs.Fnd.ApplicationForms.Int.TranslateConstantWithParams(Properties.Resources.TEXT_InventoryProductOverview, sItems));
			}

			return 0;
			#endregion
		}

     
		#endregion
		
		#region Late Bind Methods
		
		/// <summary>
		/// Virtual wrapper replacement for late-bound (..) calls.
		/// </summary>
		public override SalBoolean vrtFrameStartupUser()
		{
            using (new SalContext(this))
            {
                SetWindowTitle();
                return base.FrameStartupUser();
            }
		}

       
		#endregion 

        #region Menu Item Event Handlers

        
        #endregion

	}
}
