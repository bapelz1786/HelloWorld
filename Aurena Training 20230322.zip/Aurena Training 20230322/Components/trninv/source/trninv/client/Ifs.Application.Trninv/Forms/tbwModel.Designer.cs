#region Copyright (c) IFS Research & Development
// ======================================================================================================
//
//                 IFS Research & Development
//
//  This program is protected by copyright law and by international
//  conventions. All licensing, renting, lending or copying (including
//  for private use), and all other use of the program, which is not
//  explicitly permitted by IFS, is a violation of the rights
//  of IFS. Such violations will be reported to the
//  appropriate authorities.
//
//  VIOLATIONS OF ANY COPYRIGHT IS PUNISHABLE BY LAW AND CAN LEAD
//  TO UP TO TWO YEARS OF IMPRISONMENT AND LIABILITY TO PAY DAMAGES.
// ======================================================================================================
#endregion
#region History
#endregion

using System;
using System.Text;
using System.Drawing;
using System.Diagnostics;
using System.Collections;
using System.Windows.Forms;
using System.ComponentModel;
using Ifs.Fnd.ApplicationForms;
using PPJ.Runtime;
using PPJ.Runtime.Sql;
using PPJ.Runtime.Vis;
using PPJ.Runtime.Windows;
using PPJ.Runtime.Windows.QO;

namespace Ifs.Application.Trninv
{
	
	public partial class tbwModel
	{
		
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		#region Window Controls
		public cColumn colsBrandId;
		public cColumn colsBrandName;
		public cColumn colsCategoryId;
		public cColumn colsCategoryName;
		public cColumn colsModelId;
		public cColumn colDescription;
		#endregion
		
		#region Windows Form Designer generated code
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(tbwModel));
            this.colsBrandId = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colsBrandName = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colsCategoryId = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colsCategoryName = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colsModelId = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colDescription = new Ifs.Fnd.ApplicationForms.cColumn();
            this.SuspendLayout();
            // 
            // colsBrandId
            // 
            this.colsBrandId.MaxLength = 10;
            this.colsBrandId.Name = "colsBrandId";
            this.colsBrandId.NamedProperties.Put("EnumerateMethod", "");
            this.colsBrandId.NamedProperties.Put("FieldFlags", "71");
            this.colsBrandId.NamedProperties.Put("LovReference", "");
            this.colsBrandId.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colsBrandId.NamedProperties.Put("ResizeableChildObject", "");
            this.colsBrandId.NamedProperties.Put("SqlColumn", "BRAND_ID");
            this.colsBrandId.NamedProperties.Put("ValidateMethod", "");
            this.colsBrandId.Position = 3;
            resources.ApplyResources(this.colsBrandId, "colsBrandId");
            // 
            // colsBrandName
            // 
            this.colsBrandName.MaxLength = 2000;
            this.colsBrandName.Name = "colsBrandName";
            this.colsBrandName.NamedProperties.Put("EnumerateMethod", "");
            this.colsBrandName.NamedProperties.Put("FieldFlags", "304");
            this.colsBrandName.NamedProperties.Put("LovReference", "");
            this.colsBrandName.NamedProperties.Put("ParentName", "colsBrandId");
            this.colsBrandName.NamedProperties.Put("ResizeableChildObject", "");
            this.colsBrandName.NamedProperties.Put("SqlColumn", "Trn_Brand_API.Get_Name(BRAND_ID)");
            this.colsBrandName.NamedProperties.Put("ValidateMethod", "");
            this.colsBrandName.Position = 4;
            resources.ApplyResources(this.colsBrandName, "colsBrandName");
            // 
            // colsCategoryId
            // 
            this.colsCategoryId.MaxLength = 10;
            this.colsCategoryId.Name = "colsCategoryId";
            this.colsCategoryId.NamedProperties.Put("EnumerateMethod", "");
            this.colsCategoryId.NamedProperties.Put("FieldFlags", "67");
            this.colsCategoryId.NamedProperties.Put("LovReference", "");
            this.colsCategoryId.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colsCategoryId.NamedProperties.Put("ResizeableChildObject", "");
            this.colsCategoryId.NamedProperties.Put("SqlColumn", "CATEGORY_ID");
            this.colsCategoryId.NamedProperties.Put("ValidateMethod", "");
            this.colsCategoryId.Position = 5;
            resources.ApplyResources(this.colsCategoryId, "colsCategoryId");
            // 
            // colsCategoryName
            // 
            this.colsCategoryName.MaxLength = 2000;
            this.colsCategoryName.Name = "colsCategoryName";
            this.colsCategoryName.NamedProperties.Put("EnumerateMethod", "");
            this.colsCategoryName.NamedProperties.Put("FieldFlags", "304");
            this.colsCategoryName.NamedProperties.Put("LovReference", "");
            this.colsCategoryName.NamedProperties.Put("ParentName", "colsCategoryId");
            this.colsCategoryName.NamedProperties.Put("ResizeableChildObject", "");
            this.colsCategoryName.NamedProperties.Put("SqlColumn", "Trn_Prod_Category_API.Get_Name(CATEGORY_ID)");
            this.colsCategoryName.NamedProperties.Put("ValidateMethod", "");
            this.colsCategoryName.Position = 6;
            resources.ApplyResources(this.colsCategoryName, "colsCategoryName");
            // 
            // colsModelId
            // 
            this.colsModelId.Name = "colsModelId";
            this.colsModelId.NamedProperties.Put("EnumerateMethod", "");
            this.colsModelId.NamedProperties.Put("FieldFlags", "163");
            this.colsModelId.NamedProperties.Put("LovReference", "");
            this.colsModelId.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colsModelId.NamedProperties.Put("SqlColumn", "MODEL_ID");
            this.colsModelId.Position = 7;
            resources.ApplyResources(this.colsModelId, "colsModelId");
            // 
            // colDescription
            // 
            this.colDescription.MaxLength = 2000;
            this.colDescription.Name = "colDescription";
            this.colDescription.NamedProperties.Put("EnumerateMethod", "");
            this.colDescription.NamedProperties.Put("FieldFlags", "311");
            this.colDescription.NamedProperties.Put("LovReference", "");
            this.colDescription.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colDescription.NamedProperties.Put("SqlColumn", "DESCRIPTION");
            this.colDescription.Position = 8;
            resources.ApplyResources(this.colDescription, "colDescription");
            // 
            // tbwModel
            // 
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.colsBrandId);
            this.Controls.Add(this.colsBrandName);
            this.Controls.Add(this.colsCategoryId);
            this.Controls.Add(this.colsCategoryName);
            this.Controls.Add(this.colsModelId);
            this.Controls.Add(this.colDescription);
            this.Name = "tbwModel";
            this.NamedProperties.Put("DefaultOrderBy", "");
            this.NamedProperties.Put("DefaultWhere", "");
            this.NamedProperties.Put("LogicalUnit", "TrnModel");
            this.NamedProperties.Put("PackageName", "TRN_MODEL_API");
            this.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.NamedProperties.Put("ResizeableChildObject", "");
            this.NamedProperties.Put("SourceFlags", "449");
            this.NamedProperties.Put("ViewName", "TRN_MODEL");
            this.NamedProperties.Put("Warnings", "FALSE");
            this.Controls.SetChildIndex(this.colDescription, 0);
            this.Controls.SetChildIndex(this.colsModelId, 0);
            this.Controls.SetChildIndex(this.colsCategoryName, 0);
            this.Controls.SetChildIndex(this.colsCategoryId, 0);
            this.Controls.SetChildIndex(this.colsBrandName, 0);
            this.Controls.SetChildIndex(this.colsBrandId, 0);
            this.Controls.SetChildIndex(this.@__colObjversion, 0);
            this.Controls.SetChildIndex(this.@__colObjid, 0);
            this.ResumeLayout(false);

		}
		#endregion
		
		#region System Methods/Properties
		
		/// <summary>
		/// Release global reference.
		/// </summary>
		/// <param name="disposing"></param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null)) 
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}
		#endregion
	}
}
