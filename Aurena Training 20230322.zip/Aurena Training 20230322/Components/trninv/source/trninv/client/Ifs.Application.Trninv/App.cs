﻿#region Copyright (c) IFS Research & Development
// ======================================================================================================
//
//                 IFS Research & Development
//
//  This program is protected by copyright law and by international
//  conventions. All licensing, renting, lending or copying (including
//  for private use), and all other use of the program, which is not
//  explicitly permitted by IFS, is a violation of the rights
//  of IFS. Such violations will be reported to the
//  appropriate authorities.
//
//  VIOLATIONS OF ANY COPYRIGHT IS PUNISHABLE BY LAW AND CAN LEAD
//  TO UP TO TWO YEARS OF IMPRISONMENT AND LIABILITY TO PAY DAMAGES.
// ======================================================================================================
#endregion
#region History
#endregion

using System;
using System.Text;
using System.Drawing;
using System.Diagnostics;
using System.Collections;
using System.Windows.Forms;
using System.ComponentModel;
using Ifs.Fnd.ApplicationForms;
using PPJ.Runtime;
using PPJ.Runtime.Sql;
using PPJ.Runtime.Vis;
using PPJ.Runtime.Windows;
using PPJ.Runtime.Windows.QO;

namespace Ifs.Application.Trninv
{
	
	/// <summary>
	/// -------------------------------------------------------------------------
	/// 		IFS Research & Development
	/// 
	/// This program is protected by copyright law and by international
	/// conventions. All licensing, renting, lending or copying (including
	/// for private use), and all other use of the program, which is not
	/// expressively permitted by IFS Research & Development (IFS), is a
	/// violation of the rights of IFS. Such violations will be reported
	/// to the appropriate authorities.
	/// 
	/// VIOLATIONS OF ANY COPYRIGHT IS PUNISHABLE BY LAW AND CAN LEAD
	/// TO UP TO TWO YEARS OF IMPRISONMENT AND LIABILITY TO PAY DAMAGES.
	/// -------------------------------------------------------------------------
	/// Category:		IFS Application
	/// File:		Starter.app
	/// Purpose:		Foundation1 starter application file.
	/// -------------------------------------------------------------------------
	/// </summary>
    public class App : SalApplication
    {
        #region Global References
        
        [ThreadStatic]
        public static tbwProduct tbwProduct;

        /// <summary>
        /// Application reference to an instance of tbwInventoryProductOverview
        /// </summary>
        [ThreadStatic]
        public static tbwInventoryProductOverview tbwInventoryProductOverview;

        /// <summary>
        /// Application reference to an instance of tbwUnitOverview
        /// </summary>
        [ThreadStatic]
        public static tbwUnitOverview tbwUnitOverview;

        /// <summary>
        /// Application reference to an instance of tbwBrandOverview
        /// </summary>
        [ThreadStatic]
        public static tbwBrandOverview tbwBrandOverView;

        /// <summary>
        /// Application reference to an instance of tbwProductCategory
        /// </summary>
        [ThreadStatic]
        public static tbwProductCategory tbwProductCategory;

        /// <summary>
        /// Application reference to an instance of tbwCategoryBrand
        /// </summary>
        [ThreadStatic]
        public static tbwCategoryBrand tbwCategoryBrand;

        /// <summary>
        /// Application reference to an instance of tbwModel
        /// </summary>
        [ThreadStatic]
        public static tbwModel tbwModel;

        #endregion
    }
}
