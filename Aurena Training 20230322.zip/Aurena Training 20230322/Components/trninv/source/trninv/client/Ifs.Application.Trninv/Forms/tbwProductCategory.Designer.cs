#region Copyright (c) IFS Research & Development
// ======================================================================================================
//
//                 IFS Research & Development
//
//  This program is protected by copyright law and by international
//  conventions. All licensing, renting, lending or copying (including
//  for private use), and all other use of the program, which is not
//  explicitly permitted by IFS, is a violation of the rights
//  of IFS. Such violations will be reported to the
//  appropriate authorities.
//
//  VIOLATIONS OF ANY COPYRIGHT IS PUNISHABLE BY LAW AND CAN LEAD
//  TO UP TO TWO YEARS OF IMPRISONMENT AND LIABILITY TO PAY DAMAGES.
// ======================================================================================================
#endregion
#region History
#endregion

using System;
using System.Text;
using System.Drawing;
using System.Diagnostics;
using System.Collections;
using System.Windows.Forms;
using System.ComponentModel;
using Ifs.Fnd.ApplicationForms;
using PPJ.Runtime;
using PPJ.Runtime.Sql;
using PPJ.Runtime.Vis;
using PPJ.Runtime.Windows;
using PPJ.Runtime.Windows.QO;

namespace Ifs.Application.Trninv
{
	
	public partial class tbwProductCategory
	{
		
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		#region Window Controls
		public cColumn colsCategoryId;
		public cColumn colName;
		public cColumn colComments;
		#endregion
		
		#region Windows Form Designer generated code
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(tbwProductCategory));
            this.colsCategoryId = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colName = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colComments = new Ifs.Fnd.ApplicationForms.cColumn();
            this.SuspendLayout();
            // 
            // colsCategoryId
            // 
            this.colsCategoryId.MaxLength = 10;
            this.colsCategoryId.Name = "colsCategoryId";
            this.colsCategoryId.NamedProperties.Put("EnumerateMethod", "");
            this.colsCategoryId.NamedProperties.Put("FieldFlags", "163");
            this.colsCategoryId.NamedProperties.Put("LovReference", "");
            this.colsCategoryId.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colsCategoryId.NamedProperties.Put("ResizeableChildObject", "");
            this.colsCategoryId.NamedProperties.Put("SqlColumn", "CATEGORY_ID");
            this.colsCategoryId.NamedProperties.Put("ValidateMethod", "");
            this.colsCategoryId.Position = 3;
            resources.ApplyResources(this.colsCategoryId, "colsCategoryId");
            // 
            // colName
            // 
            this.colName.MaxLength = 1000;
            this.colName.Name = "colName";
            this.colName.NamedProperties.Put("EnumerateMethod", "");
            this.colName.NamedProperties.Put("FieldFlags", "311");
            this.colName.NamedProperties.Put("LovReference", "");
            this.colName.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colName.NamedProperties.Put("SqlColumn", "NAME");
            this.colName.Position = 4;
            resources.ApplyResources(this.colName, "colName");
            // 
            // colComments
            // 
            this.colComments.MaxLength = 2000;
            this.colComments.Name = "colComments";
            this.colComments.NamedProperties.Put("EnumerateMethod", "");
            this.colComments.NamedProperties.Put("FieldFlags", "310");
            this.colComments.NamedProperties.Put("LovReference", "");
            this.colComments.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colComments.NamedProperties.Put("SqlColumn", "COMMENTS");
            this.colComments.Position = 5;
            resources.ApplyResources(this.colComments, "colComments");
            // 
            // tbwProductCategory
            // 
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.colsCategoryId);
            this.Controls.Add(this.colName);
            this.Controls.Add(this.colComments);
            this.Name = "tbwProductCategory";
            this.NamedProperties.Put("DefaultOrderBy", "");
            this.NamedProperties.Put("DefaultWhere", "");
            this.NamedProperties.Put("LogicalUnit", "TrnProdCategory");
            this.NamedProperties.Put("PackageName", "TRN_PROD_CATEGORY_API");
            this.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.NamedProperties.Put("ResizeableChildObject", "");
            this.NamedProperties.Put("SourceFlags", "449");
            this.NamedProperties.Put("ViewName", "TRN_PROD_CATEGORY");
            this.NamedProperties.Put("Warnings", "FALSE");
            this.Controls.SetChildIndex(this.colComments, 0);
            this.Controls.SetChildIndex(this.colName, 0);
            this.Controls.SetChildIndex(this.colsCategoryId, 0);
            this.Controls.SetChildIndex(this.@__colObjversion, 0);
            this.Controls.SetChildIndex(this.@__colObjid, 0);
            this.ResumeLayout(false);

		}
		#endregion
		
		#region System Methods/Properties
		
		/// <summary>
		/// Release global reference.
		/// </summary>
		/// <param name="disposing"></param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null)) 
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}
		#endregion
	}
}
