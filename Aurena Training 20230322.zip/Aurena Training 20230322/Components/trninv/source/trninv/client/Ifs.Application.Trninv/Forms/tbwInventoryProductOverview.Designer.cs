#region Copyright (c) IFS Research & Development
// ======================================================================================================
//
//                 IFS Research & Development
//
//  This program is protected by copyright law and by international
//  conventions. All licensing, renting, lending or copying (including
//  for private use), and all other use of the program, which is not
//  explicitly permitted by IFS, is a violation of the rights
//  of IFS. Such violations will be reported to the
//  appropriate authorities.
//
//  VIOLATIONS OF ANY COPYRIGHT IS PUNISHABLE BY LAW AND CAN LEAD
//  TO UP TO TWO YEARS OF IMPRISONMENT AND LIABILITY TO PAY DAMAGES.
// ======================================================================================================
#endregion
#region History
#endregion

using System;
using System.Text;
using System.Drawing;
using System.Diagnostics;
using System.Collections;
using System.Windows.Forms;
using System.ComponentModel;
using Ifs.Fnd.ApplicationForms;
using PPJ.Runtime;
using PPJ.Runtime.Sql;
using PPJ.Runtime.Vis;
using PPJ.Runtime.Windows;
using PPJ.Runtime.Windows.QO;

namespace Ifs.Application.Trninv
{
	
	public partial class tbwInventoryProductOverview
	{
		
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		#region Window Controls
		public cColumn colsCompanyId;
		public cColumn colsBranchId;
		public cColumn colnInventoryId;
		public cColumn colnProductId;
		public cColumn colDemoProductUnit;
		public cColumn colDemoProductBrandId;
		public cColumn colDemoProductCategoryId;
		public cColumn colDemoProductModelId;
		public cColumn colnQuantity;
		public cColumn colnReorderLevel;
		public cColumn colnReservedQuantity;
		#endregion
		
		#region Windows Form Designer generated code
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(tbwInventoryProductOverview));
            this.colsCompanyId = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colsBranchId = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colnInventoryId = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colnProductId = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colDemoProductUnit = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colDemoProductBrandId = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colDemoProductCategoryId = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colDemoProductModelId = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colnQuantity = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colnReorderLevel = new Ifs.Fnd.ApplicationForms.cColumn();
            this.colnReservedQuantity = new Ifs.Fnd.ApplicationForms.cColumn();
            this.SuspendLayout();
            // 
            // colsCompanyId
            // 
            this.colsCompanyId.MaxLength = 20;
            this.colsCompanyId.Name = "colsCompanyId";
            this.colsCompanyId.NamedProperties.Put("EnumerateMethod", "");
            this.colsCompanyId.NamedProperties.Put("FieldFlags", "99");
            this.colsCompanyId.NamedProperties.Put("LovReference", "");
            this.colsCompanyId.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colsCompanyId.NamedProperties.Put("SqlColumn", "COMPANY_ID");
            this.colsCompanyId.NamedProperties.Put("ValidateMethod", "");
            this.colsCompanyId.Position = 3;
            resources.ApplyResources(this.colsCompanyId, "colsCompanyId");
            // 
            // colsBranchId
            // 
            this.colsBranchId.MaxLength = 20;
            this.colsBranchId.Name = "colsBranchId";
            this.colsBranchId.NamedProperties.Put("EnumerateMethod", "");
            this.colsBranchId.NamedProperties.Put("FieldFlags", "99");
            this.colsBranchId.NamedProperties.Put("LovReference", "TRN_BRANCH(COMPANY_ID)");
            this.colsBranchId.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colsBranchId.NamedProperties.Put("ResizeableChildObject", "");
            this.colsBranchId.NamedProperties.Put("SqlColumn", "BRANCH_ID");
            this.colsBranchId.NamedProperties.Put("ValidateMethod", "");
            this.colsBranchId.Position = 4;
            resources.ApplyResources(this.colsBranchId, "colsBranchId");
            // 
            // colnInventoryId
            // 
            this.colnInventoryId.DataType = PPJ.Runtime.Windows.DataType.Number;
            this.colnInventoryId.Name = "colnInventoryId";
            this.colnInventoryId.NamedProperties.Put("EnumerateMethod", "");
            this.colnInventoryId.NamedProperties.Put("FieldFlags", "99");
            this.colnInventoryId.NamedProperties.Put("LovReference", "TRN_INVENTORY(COMPANY_ID,BRANCH_ID)");
            this.colnInventoryId.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colnInventoryId.NamedProperties.Put("ResizeableChildObject", "");
            this.colnInventoryId.NamedProperties.Put("SqlColumn", "INVENTORY_ID");
            this.colnInventoryId.NamedProperties.Put("ValidateMethod", "");
            this.colnInventoryId.Position = 5;
            resources.ApplyResources(this.colnInventoryId, "colnInventoryId");
            // 
            // colnProductId
            // 
            this.colnProductId.DataType = PPJ.Runtime.Windows.DataType.Number;
            this.colnProductId.Name = "colnProductId";
            this.colnProductId.NamedProperties.Put("EnumerateMethod", "");
            this.colnProductId.NamedProperties.Put("FieldFlags", "99");
            this.colnProductId.NamedProperties.Put("LovReference", "TRN_PRODUCT(COMPANY_ID)");
            this.colnProductId.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colnProductId.NamedProperties.Put("ResizeableChildObject", "");
            this.colnProductId.NamedProperties.Put("SqlColumn", "PRODUCT_ID");
            this.colnProductId.NamedProperties.Put("ValidateMethod", "");
            this.colnProductId.Position = 6;
            resources.ApplyResources(this.colnProductId, "colnProductId");
            // 
            // colDemoProductUnit
            // 
            this.colDemoProductUnit.MaxLength = 2000;
            this.colDemoProductUnit.Name = "colDemoProductUnit";
            this.colDemoProductUnit.NamedProperties.Put("EnumerateMethod", "");
            this.colDemoProductUnit.NamedProperties.Put("FieldFlags", "272");
            this.colDemoProductUnit.NamedProperties.Put("LovReference", "");
            this.colDemoProductUnit.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colDemoProductUnit.NamedProperties.Put("ResizeableChildObject", "");
            this.colDemoProductUnit.NamedProperties.Put("SqlColumn", "TRN_PRODUCT_API.Get_Unit(company_id,PRODUCT_ID)");
            this.colDemoProductUnit.NamedProperties.Put("ValidateMethod", "");
            this.colDemoProductUnit.Position = 7;
            resources.ApplyResources(this.colDemoProductUnit, "colDemoProductUnit");
            // 
            // colDemoProductBrandId
            // 
            this.colDemoProductBrandId.MaxLength = 2000;
            this.colDemoProductBrandId.Name = "colDemoProductBrandId";
            this.colDemoProductBrandId.NamedProperties.Put("EnumerateMethod", "");
            this.colDemoProductBrandId.NamedProperties.Put("FieldFlags", "304");
            this.colDemoProductBrandId.NamedProperties.Put("LovReference", "");
            this.colDemoProductBrandId.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colDemoProductBrandId.NamedProperties.Put("ResizeableChildObject", "");
            this.colDemoProductBrandId.NamedProperties.Put("SqlColumn", "TRN_PRODUCT_API.Get_Brand_Id(company_id,PRODUCT_ID)");
            this.colDemoProductBrandId.NamedProperties.Put("ValidateMethod", "");
            this.colDemoProductBrandId.Position = 8;
            resources.ApplyResources(this.colDemoProductBrandId, "colDemoProductBrandId");
            // 
            // colDemoProductCategoryId
            // 
            this.colDemoProductCategoryId.MaxLength = 2000;
            this.colDemoProductCategoryId.Name = "colDemoProductCategoryId";
            this.colDemoProductCategoryId.NamedProperties.Put("EnumerateMethod", "");
            this.colDemoProductCategoryId.NamedProperties.Put("FieldFlags", "304");
            this.colDemoProductCategoryId.NamedProperties.Put("LovReference", "");
            this.colDemoProductCategoryId.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colDemoProductCategoryId.NamedProperties.Put("ResizeableChildObject", "");
            this.colDemoProductCategoryId.NamedProperties.Put("SqlColumn", "TRN_PRODUCT_API.Get_Category_Id(company_id,PRODUCT_ID)");
            this.colDemoProductCategoryId.NamedProperties.Put("ValidateMethod", "");
            this.colDemoProductCategoryId.Position = 9;
            resources.ApplyResources(this.colDemoProductCategoryId, "colDemoProductCategoryId");
            // 
            // colDemoProductModelId
            // 
            this.colDemoProductModelId.MaxLength = 2000;
            this.colDemoProductModelId.Name = "colDemoProductModelId";
            this.colDemoProductModelId.NamedProperties.Put("EnumerateMethod", "");
            this.colDemoProductModelId.NamedProperties.Put("FieldFlags", "304");
            this.colDemoProductModelId.NamedProperties.Put("LovReference", "");
            this.colDemoProductModelId.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colDemoProductModelId.NamedProperties.Put("ResizeableChildObject", "");
            this.colDemoProductModelId.NamedProperties.Put("SqlColumn", "TRN_PRODUCT_API.Get_Model_Id(company_id,PRODUCT_ID)");
            this.colDemoProductModelId.NamedProperties.Put("ValidateMethod", "");
            this.colDemoProductModelId.Position = 10;
            resources.ApplyResources(this.colDemoProductModelId, "colDemoProductModelId");
            // 
            // colnQuantity
            // 
            this.colnQuantity.DataType = PPJ.Runtime.Windows.DataType.Number;
            this.colnQuantity.Name = "colnQuantity";
            this.colnQuantity.NamedProperties.Put("EnumerateMethod", "");
            this.colnQuantity.NamedProperties.Put("FieldFlags", "131");
            this.colnQuantity.NamedProperties.Put("LovReference", "");
            this.colnQuantity.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colnQuantity.NamedProperties.Put("SqlColumn", "QUANTITY");
            this.colnQuantity.NamedProperties.Put("ValidateMethod", "");
            this.colnQuantity.Position = 11;
            resources.ApplyResources(this.colnQuantity, "colnQuantity");
            // 
            // colnReorderLevel
            // 
            this.colnReorderLevel.DataType = PPJ.Runtime.Windows.DataType.Number;
            this.colnReorderLevel.Name = "colnReorderLevel";
            this.colnReorderLevel.NamedProperties.Put("EnumerateMethod", "");
            this.colnReorderLevel.NamedProperties.Put("FieldFlags", "263");
            this.colnReorderLevel.NamedProperties.Put("LovReference", "");
            this.colnReorderLevel.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colnReorderLevel.NamedProperties.Put("SqlColumn", "REORDER_LEVEL");
            this.colnReorderLevel.NamedProperties.Put("ValidateMethod", "");
            this.colnReorderLevel.Position = 12;
            resources.ApplyResources(this.colnReorderLevel, "colnReorderLevel");
            // 
            // colnReservedQuantity
            // 
            this.colnReservedQuantity.DataType = PPJ.Runtime.Windows.DataType.Number;
            this.colnReservedQuantity.Name = "colnReservedQuantity";
            this.colnReservedQuantity.NamedProperties.Put("EnumerateMethod", "");
            this.colnReservedQuantity.NamedProperties.Put("FieldFlags", "263");
            this.colnReservedQuantity.NamedProperties.Put("LovReference", "");
            this.colnReservedQuantity.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.colnReservedQuantity.NamedProperties.Put("SqlColumn", "RESERVED_QUANTITY");
            this.colnReservedQuantity.NamedProperties.Put("ValidateMethod", "");
            this.colnReservedQuantity.Position = 13;
            resources.ApplyResources(this.colnReservedQuantity, "colnReservedQuantity");
            // 
            // tbwInventoryProductOverview
            // 
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.colsCompanyId);
            this.Controls.Add(this.colsBranchId);
            this.Controls.Add(this.colnInventoryId);
            this.Controls.Add(this.colnProductId);
            this.Controls.Add(this.colDemoProductUnit);
            this.Controls.Add(this.colDemoProductBrandId);
            this.Controls.Add(this.colDemoProductCategoryId);
            this.Controls.Add(this.colDemoProductModelId);
            this.Controls.Add(this.colnQuantity);
            this.Controls.Add(this.colnReorderLevel);
            this.Controls.Add(this.colnReservedQuantity);
            this.Name = "tbwInventoryProductOverview";
            this.NamedProperties.Put("DefaultOrderBy", "");
            this.NamedProperties.Put("DefaultWhere", "COMPANY_ID = :Global.Company_Id");
            this.NamedProperties.Put("LogicalUnit", "TrnInventoryProduct");
            this.NamedProperties.Put("PackageName", "TRN_INVENTORY_PRODUCT_API");
            this.NamedProperties.Put("ParentName", "[NaturalParent]");
            this.NamedProperties.Put("ResizeableChildObject", "");
            this.NamedProperties.Put("SourceFlags", "129");
            this.NamedProperties.Put("ViewName", "TRN_INVENTORY_PRODUCT");
            this.NamedProperties.Put("Warnings", "FALSE");
            this.Controls.SetChildIndex(this.colnReservedQuantity, 0);
            this.Controls.SetChildIndex(this.colnReorderLevel, 0);
            this.Controls.SetChildIndex(this.colnQuantity, 0);
            this.Controls.SetChildIndex(this.colDemoProductModelId, 0);
            this.Controls.SetChildIndex(this.colDemoProductCategoryId, 0);
            this.Controls.SetChildIndex(this.colDemoProductBrandId, 0);
            this.Controls.SetChildIndex(this.colDemoProductUnit, 0);
            this.Controls.SetChildIndex(this.colnProductId, 0);
            this.Controls.SetChildIndex(this.colnInventoryId, 0);
            this.Controls.SetChildIndex(this.colsBranchId, 0);
            this.Controls.SetChildIndex(this.colsCompanyId, 0);
            this.Controls.SetChildIndex(this.@__colObjversion, 0);
            this.Controls.SetChildIndex(this.@__colObjid, 0);
            this.ResumeLayout(false);

		}
		#endregion
		
		#region System Methods/Properties
		
		/// <summary>
		/// Release global reference.
		/// </summary>
		/// <param name="disposing"></param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null)) 
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}
		#endregion

    }
}
